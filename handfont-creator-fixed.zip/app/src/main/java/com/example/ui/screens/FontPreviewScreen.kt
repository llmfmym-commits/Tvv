package com.example.ui.screens

import android.content.Intent
import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.models.StylePreset
import com.example.engine.shaping.PersianShaper
import com.example.ui.viewmodel.FontStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FontPreviewScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val currentProject by viewModel.currentProject.collectAsState()
    val ttfFile by viewModel.exportedTtfFile.collectAsState()

    var testText by remember { mutableStateOf("سلام دنیا! این دستخط واقعی من است که به فونت تبدیل شده است.") }
    var fontSizeSp by remember { mutableFloatStateOf(26f) }
    var naturalness by remember { mutableFloatStateOf(0.7f) }
    var selectedPreset by remember { mutableStateOf(StylePreset.NATURAL) }

    val presetPhrases = listOf(
        "سلام دنیا! این دستخط من است.",
        "ن والقلم وما یسطرون",
        "The quick brown fox jumps over the lazy dog.",
        "۰ ۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹",
        "این یک یادداشت کاملاً طبیعی با قلم است."
    )

    // Attempt to load Typeface from real TTF
    val customTypeface = remember(ttfFile) {
        if (ttfFile != null && ttfFile!!.exists()) {
            try {
                Typeface.createFromFile(ttfFile)
            } catch (e: Exception) {
                null
            }
        } else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("پیش‌نمایش فونت دستخط", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("preview_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (ttfFile != null) {
                        IconButton(
                            onClick = {
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.provider",
                                    ttfFile!!
                                )
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/x-font-ttf"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "ارسال فایل TTF"))
                            },
                            modifier = Modifier.testTag("share_ttf_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share TTF")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("font_preview_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // TTF Generation Action Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ttf_status_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (ttfFile != null) "فایل فونت: ${ttfFile?.name}" else "فایل TTF هنوز ساخته نشده",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (ttfFile != null) "اندازه: ${(ttfFile?.length() ?: 0) / 1024} KB | فرمت TrueType استاندارد" else "برای بارگذاری فونت زنده، دکمه تولید را بزنید.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { viewModel.generateTtf() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("generate_ttf_button")
                    ) {
                        Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("تولید TTF", fontSize = 12.sp)
                    }
                }
            }

            // Quick Preset Phrases
            Text("نمونه‌های آماده برای آزمایش:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presetPhrases.forEach { phrase ->
                    FilterChip(
                        selected = testText == phrase,
                        onClick = { testText = phrase },
                        label = { Text(phrase, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }

            // Style Preset selector (Section 24)
            Text("سبک و رفتار دستخط (Style):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StylePreset.values().forEach { preset ->
                    FilterChip(
                        selected = selectedPreset == preset,
                        onClick = {
                            selectedPreset = preset
                            naturalness = preset.naturalness
                        },
                        label = { Text(preset.farsiTitle, fontSize = 11.sp) }
                    )
                }
            }

            // Text Input Box
            OutlinedTextField(
                value = testText,
                onValueChange = { testText = it },
                label = { Text("متن دلخواه برای تست دستخط") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("preview_text_input"),
                maxLines = 3,
                shape = RoundedCornerShape(12.dp)
            )

            // Live Preview Canvas Container
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFBF9)) // Creamy paper tint
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                        .testTag("live_rendered_text_box")
                ) {
                    Text(
                        text = "پیش‌نمایش خروجی دستخط:",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(Modifier.height(10.dp))

                    // Text rendered with custom font
                    Text(
                        text = testText,
                        fontSize = fontSizeSp.sp,
                        lineHeight = (fontSizeSp * 1.5f).sp,
                        color = Color(0xFF1E3A8A), // Royal blue ink
                        fontFamily = customTypeface?.let { FontFamily(it) } ?: FontFamily.Default,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Sliders: Size & Naturalness
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("اندازه قلم:", fontSize = 12.sp)
                        Text("${fontSizeSp.toInt()} sp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = fontSizeSp,
                        onValueChange = { fontSizeSp = it },
                        valueRange = 16f..64f
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("میزان طبیعی بودن دستخط (Naturalization):", fontSize = 12.sp)
                        Text("${(naturalness * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = naturalness,
                        onValueChange = { naturalness = it },
                        valueRange = 0.0f..1.0f
                    )
                }
            }
        }
    }
}
