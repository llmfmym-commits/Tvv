package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.models.DrawnStroke
import com.example.data.models.PencilHardness
import com.example.data.models.ToolType
import com.example.ui.components.StylusCanvas
import com.example.ui.viewmodel.FontStudioViewModel
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignatureMakerScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val savedSignatures by viewModel.allSignatures.collectAsState()

    val strokes = remember { mutableStateListOf<DrawnStroke>() }
    var signatureTitle by remember { mutableStateOf("امضای رسمی من") }
    var selectedInkColor by remember { mutableStateOf(0xFF1E3A8AL) } // Blue ink
    var strokeWidth by remember { mutableFloatStateOf(16f) }

    val inkColors = listOf(
        Pair("آبی کلاسیک", 0xFF1E3A8AL),
        Pair("مشکی رسمی", 0xFF0A0A0AL),
        Pair("زرشکی", 0xFF881337L)
    )

    fun createCroppedTransparentBitmap(): Bitmap? {
        if (strokes.isEmpty()) return null

        // 1. Calculate tight bounding box
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE
        var maxY = Float.MIN_VALUE

        for (s in strokes) {
            for (p in s.points) {
                if (p.x < minX) minX = p.x
                if (p.y < minY) minY = p.y
                if (p.x > maxX) maxX = p.x
                if (p.y > maxY) maxY = p.y
            }
        }

        val padding = 20f
        val w = max(50, ((maxX - minX) + padding * 2).toInt())
        val h = max(50, ((maxY - minY) + padding * 2).toInt())

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(bitmap)
        // Canvas is initially completely transparent

        val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
            color = selectedInkColor.toInt()
            style = AndroidPaint.Style.STROKE
            strokeCap = AndroidPaint.Cap.ROUND
            strokeJoin = AndroidPaint.Join.ROUND
        }

        for (s in strokes) {
            paint.strokeWidth = s.strokeWidth
            for (i in 0 until s.points.size - 1) {
                val p1 = s.points[i]
                val p2 = s.points[i + 1]
                val x1 = p1.x - minX + padding
                val y1 = p1.y - minY + padding
                val x2 = p2.x - minX + padding
                val y2 = p2.y - minY + padding
                canvas.drawLine(x1, y1, x2, y2, paint)
            }
        }

        return bitmap
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ساخت امضای دیجیتال", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("signature_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { strokes.clear() },
                        modifier = Modifier.testTag("clear_signature_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("signature_maker_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Instruction
            Text(
                text = "امضای خود را با قلم یا انگشت داخل کادر زیر بکشید. برنامه حاشیه‌ها را به‌صورت هوشمند برش زده و تصویر PNG شفاف با کیفیت بالا تولید می‌کند.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Ink color selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                inkColors.forEach { (name, color) ->
                    FilterChip(
                        selected = selectedInkColor == color,
                        onClick = { selectedInkColor = color },
                        label = { Text(name, fontSize = 12.sp) }
                    )
                }
            }

            // Drawing Area Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.3f)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .testTag("signature_canvas_card"),
                shape = RoundedCornerShape(16.dp)
            ) {
                StylusCanvas(
                    modifier = Modifier.fillMaxSize(),
                    strokes = strokes,
                    currentTool = ToolType.PEN,
                    currentColor = selectedInkColor,
                    currentStrokeWidth = strokeWidth,
                    pencilHardness = PencilHardness.B2,
                    showGuides = false,
                    onStrokeFinished = { strokes.add(it) }
                )
            }

            OutlinedTextField(
                value = signatureTitle,
                onValueChange = { signatureTitle = it },
                label = { Text("عنوان امضا") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signature_title_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // Save & Export Button
            Button(
                onClick = {
                    val bmp = createCroppedTransparentBitmap()
                    if (bmp != null) {
                        viewModel.saveSignature(signatureTitle, bmp)
                        strokes.clear()
                    }
                },
                enabled = strokes.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_signature_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("ذخیره امضا (خروجی PNG شفاف)", fontWeight = FontWeight.Bold)
            }

            // Saved Signatures Gallery
            if (savedSignatures.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("امضاهای ذخیره شده:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(savedSignatures) { sig ->
                        Card(
                            modifier = Modifier
                                .width(150.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Decode base64 PNG preview
                                val bmp = remember(sig.pngBase64) {
                                    try {
                                        val bytes = Base64.decode(sig.pngBase64, Base64.DEFAULT)
                                        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                    } catch (_: Exception) { null }
                                }
                                Box(
                                    modifier = Modifier
                                        .size(120.dp, 60.dp)
                                        .background(Color.White, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (bmp != null) {
                                        Image(bitmap = bmp.asImageBitmap(), contentDescription = sig.title)
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(sig.title, fontSize = 11.sp, fontWeight = FontWeight.Medium)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (bmp != null) {
                                                val file = File(context.cacheDir, "signature_${sig.id}.png")
                                                FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "image/png"
                                                    putExtra(Intent.EXTRA_STREAM, uri)
                                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری امضا"))
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(onClick = { viewModel.deleteSignature(sig) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
