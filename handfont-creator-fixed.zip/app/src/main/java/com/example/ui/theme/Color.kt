package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AmberPrimary = Color(0xFFD97706)
val AmberSecondary = Color(0xFFF59E0B)
val InkBlue = Color(0xFF1E3A8A)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)

val GraphiteDark = Color(0xFF2F3237)
val SoftGraphite = Color(0xFF64748B)
