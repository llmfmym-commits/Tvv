package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.FontStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FontInspectorScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val project by viewModel.currentProject.collectAsState()
    val stats by viewModel.handwritingStats.collectAsState()
    val glyphs by viewModel.projectGlyphs.collectAsState()
    val ttfFile by viewModel.exportedTtfFile.collectAsState()

    val capturedCount = glyphs.count { it.strokesJson.isNotBlank() && it.strokesJson != "[]" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مشخصات فنی فونت (Inspector)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("inspector_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("font_inspector_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // General Font Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("شناسنامه فونت:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    InspectorRow("نام فونت (Font Name)", project?.name ?: "دستخط من")
                    InspectorRow("خانواده (Family Name)", project?.familyName ?: "HandFont")
                    InspectorRow("پدیدآورنده (Author)", project?.author ?: "User")
                    InspectorRow("نسخه (Version)", project?.version ?: "1.0")
                    InspectorRow("فایل باینری", if (ttfFile != null) "${ttfFile?.name} (${ttfFile?.length()?.div(1024)} KB)" else "تولید نشده")
                }
            }

            // Typography Metrics (Section 18)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("متریک‌های تایپوگرافی (Font Metrics):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    InspectorRow("Units Per Em (UPM)", "${project?.upm ?: 1024}")
                    InspectorRow("صعودی (Ascender)", "+${project?.ascender ?: 800}")
                    InspectorRow("نزولی (Descender)", "${project?.descender ?: -200}")
                    InspectorRow("خط زمینه (Baseline)", "0 (Y-Axis Normalized)")
                    InspectorRow("تعداد گلیف‌های فعال", "$capturedCount")
                }
            }

            // OpenType Tables & Shaping Features
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("جداول OpenType و ویژگی‌های اتصال:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))

                    val features = listOf(
                        Pair("پشتیبانی از زبان فارسی (Persian/Arabic)", true),
                        Pair("پشتیبانی از زبان انگلیسی (Basic Latin)", true),
                        Pair("جهت‌گیری راست‌به‌چپ (RTL Engine)", true),
                        Pair("شکل‌گیری متنی (Contextual Shaping)", true),
                        Pair("اشکال متصل (Initial / Medial / Final)", true),
                        Pair("جدول نقشه یونیکد (cmap Format 4)", true),
                        Pair("طرح خطوط کلی (glyf + loca 32-bit)", true),
                        Pair("جدول فراداده و کپی‌رایت (name Table)", true),
                        Pair("متریک افقی (hmtx + hhea)", true),
                        Pair("سازگاری با ویندوز و اندروید (OS/2 Table)", true)
                    )

                    features.forEach { (feat, supported) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(feat, fontSize = 12.sp)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("فعال ✓", color = Color(0xFF065F46), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InspectorRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
