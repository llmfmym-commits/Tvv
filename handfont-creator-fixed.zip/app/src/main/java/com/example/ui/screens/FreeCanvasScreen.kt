package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.models.DrawnStroke
import com.example.data.models.PenType
import com.example.data.models.PencilHardness
import com.example.data.models.ToolType
import com.example.ui.components.DrawingToolBar
import com.example.ui.components.StylusCanvas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreeCanvasScreen(
    onBack: () -> Unit
) {
    val strokes = remember { mutableStateListOf<DrawnStroke>() }
    val undoStack = remember { mutableStateListOf<List<DrawnStroke>>() }
    val redoStack = remember { mutableStateListOf<List<DrawnStroke>>() }

    var currentTool by remember { mutableStateOf(ToolType.PENCIL) }
    var currentColorArgb by remember { mutableStateOf(0xFF2F3237L) }
    var currentStrokeWidth by remember { mutableFloatStateOf(14f) }
    var pencilHardness by remember { mutableStateOf(PencilHardness.B2) }
    var penType by remember { mutableStateOf(PenType.BALLPOINT) }

    fun addStroke(s: DrawnStroke) {
        undoStack.add(strokes.toList())
        redoStack.clear()
        strokes.add(s)
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val last = undoStack.removeAt(undoStack.size - 1)
            redoStack.add(strokes.toList())
            strokes.clear()
            strokes.addAll(last)
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.size - 1)
            undoStack.add(strokes.toList())
            strokes.clear()
            strokes.addAll(next)
        }
    }

    fun clearAll() {
        if (strokes.isNotEmpty()) {
            undoStack.add(strokes.toList())
            redoStack.clear()
            strokes.clear()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("صفحه آزاد یادداشت و طراحی", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("free_canvas_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { clearAll() },
                        modifier = Modifier.testTag("free_canvas_clear_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("free_canvas_screen")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(0.dp))
            ) {
                StylusCanvas(
                    modifier = Modifier.fillMaxSize(),
                    strokes = strokes,
                    currentTool = currentTool,
                    currentColor = currentColorArgb,
                    currentStrokeWidth = currentStrokeWidth,
                    pencilHardness = pencilHardness,
                    showGuides = false,
                    onStrokeFinished = { addStroke(it) }
                )
            }

            DrawingToolBar(
                currentTool = currentTool,
                currentColorArgb = currentColorArgb,
                currentStrokeWidth = currentStrokeWidth,
                pencilHardness = pencilHardness,
                penType = penType,
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                onToolSelected = { currentTool = it },
                onColorSelected = { currentColorArgb = it },
                onStrokeWidthChanged = { currentStrokeWidth = it },
                onPencilHardnessSelected = { pencilHardness = it },
                onPenTypeSelected = { penType = it },
                onUndo = { undo() },
                onRedo = { redo() },
                onClear = { clearAll() },
                onConfirm = { /* In free canvas, strokes remain active */ }
            )
        }
    }
}
