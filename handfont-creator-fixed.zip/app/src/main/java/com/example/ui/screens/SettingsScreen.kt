package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.FontStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val project by viewModel.currentProject.collectAsState()

    var fontName by remember(project) { mutableStateOf(project?.name ?: "") }
    var author by remember(project) { mutableStateOf(project?.author ?: "") }
    var version by remember(project) { mutableStateOf(project?.version ?: "1.0") }
    var description by remember(project) { mutableStateOf(project?.description ?: "") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تنظیمات و درباره برنامه", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("settings_screen"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Font Metadata Editing (Section 70)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("فراداده و مشخصات فونت جاری (Metadata):", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                    OutlinedTextField(
                        value = fontName,
                        onValueChange = { fontName = it },
                        label = { Text("نام فونت") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = author,
                        onValueChange = { author = it },
                        label = { Text("طراح و صاحب اثر") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = version,
                        onValueChange = { version = it },
                        label = { Text("شماره نسخه") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("توضیحات فونت") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Button(
                        onClick = {
                            viewModel.updateProjectMetadata(
                                name = fontName,
                                author = author,
                                version = version,
                                description = description
                            )
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("ذخیره مشخصات فونت")
                    }
                }
            }

            // Android Font Limitations Info (Section 61)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        Text("راهنمای استفاده از فونت TTF در اندروید:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "سیستم‌عامل اندروید به دلایل امنیتی امکان تغییر فونت سراسری بدون روت یا برنامه‌های اختصاصی لانچر را نمی‌دهد. فونت تولیدشده این استودیو، یک فایل TTF استاندارد واقعی است که می‌توانید:\n" +
                                "۱. آن را مستقیماً داخل خود برنامه برای نوشتن روی عکس، دفتر و تولید PDF به کار ببرید.\n" +
                                "۲. فایل TTF را در نرم‌افزارهای گرافیکی (مانند Photoshop، Word، InShot، VN، Canva و ...) ایمپورت و استفاده کنید.",
                        fontSize = 11.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            // Completely Offline Privacy Guarantee (Section 4)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row {
                        Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        Text("امنیت و کارکرد ۱۰۰٪ آفلاین:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "تمامی عملیات ساخت و نرمال‌سازی گلیف‌ها، تولید فایل TTF، رندر دستخط روی تصویر و ساخت PDF به‌صورت محلی روی حافظه دستگاه شما انجام می‌شود و هیچ داده یا تصویری به سرورهای خارجی ارسال نمی‌گردد.",
                        fontSize = 11.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

