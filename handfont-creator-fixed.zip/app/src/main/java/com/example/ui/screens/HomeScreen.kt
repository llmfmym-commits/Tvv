package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.ScreenRoute
import com.example.ui.viewmodel.FontStudioViewModel

data class StudioActionItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val route: String,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FontStudioViewModel,
    onNavigate: (String) -> Unit
) {
    val currentProject by viewModel.currentProject.collectAsState()
    val stats by viewModel.handwritingStats.collectAsState()
    val ttfFile by viewModel.exportedTtfFile.collectAsState()

    val actionItems = listOf(
        StudioActionItem(
            title = "جمع‌آوری حروف",
            subtitle = "نوشتن مرحله‌به‌مرحله با قلم",
            icon = Icons.Default.Create,
            color = Color(0xFF2563EB),
            route = ScreenRoute.GlyphCollection.route,
            testTag = "action_collect_glyphs"
        ),
        StudioActionItem(
            title = "پیش‌نمایش فونت",
            subtitle = "تست و تایپ دستخط زنده",
            icon = Icons.Default.TextFields,
            color = Color(0xFFD97706),
            route = ScreenRoute.FontPreview.route,
            testTag = "action_preview_font"
        ),
        StudioActionItem(
            title = "نوشتن روی تصویر",
            subtitle = "تشخیص خطوط دفتر و پرسپکتیو",
            icon = Icons.Default.Image,
            color = Color(0xFF059669),
            route = ScreenRoute.PaperWriter.route,
            testTag = "action_paper_writer"
        ),
        StudioActionItem(
            title = "ساخت PDF دستنویس",
            subtitle = "تبدیل متن به صفحات دست‌نویس",
            icon = Icons.Default.PictureAsPdf,
            color = Color(0xFFDC2626),
            route = ScreenRoute.PdfMaker.route,
            testTag = "action_pdf_maker"
        ),
        StudioActionItem(
            title = "امضای من",
            subtitle = "برش و پس‌زمینه شفاف PNG",
            icon = Icons.Default.Draw,
            color = Color(0xFF7C3AED),
            route = ScreenRoute.SignatureMaker.route,
            testTag = "action_signature_maker"
        ),
        StudioActionItem(
            title = "آزمایش دستخط",
            subtitle = "تحلیل کیفیت و جملات تشخیصی",
            icon = Icons.Default.Assessment,
            color = Color(0xFF0284C7),
            route = ScreenRoute.HandwritingTest.route,
            testTag = "action_handwriting_test"
        ),
        StudioActionItem(
            title = "صفحه آزاد",
            subtitle = "طراحی و یادداشت آزاد قلم و مداد",
            icon = Icons.Default.EditNote,
            color = Color(0xFF475569),
            route = ScreenRoute.FreeCanvas.route,
            testTag = "action_free_canvas"
        ),
        StudioActionItem(
            title = "استخراج از عکس",
            subtitle = "جداسازی حروف از کاغذ نوشته‌شده",
            icon = Icons.Default.CropFree,
            color = Color(0xFF0D9488),
            route = ScreenRoute.PhotoExtraction.route,
            testTag = "action_photo_extraction"
        ),
        StudioActionItem(
            title = "مشخصات فنی فونت",
            subtitle = "جداول TTF، کرنینگ و متریک‌ها",
            icon = Icons.Default.Info,
            color = Color(0xFF4F46E5),
            route = ScreenRoute.FontInspector.route,
            testTag = "action_font_inspector"
        ),
        StudioActionItem(
            title = "فونت‌های من",
            subtitle = "پروژه‌ها، بکاپ HFP و تاریخچه",
            icon = Icons.Default.Folder,
            color = Color(0xFF64748B),
            route = ScreenRoute.MyProjects.route,
            testTag = "action_my_projects"
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFF59E0B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("HF", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("HandFont Creator", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("استودیوی ساخت دستخط و فونت دیجیتال", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onNavigate(ScreenRoute.Settings.route) },
                        modifier = Modifier.testTag("home_settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("home_screen_grid"),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Project Status Hero Banner
            item(span = { GridItemSpan(2) }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("hero_project_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = currentProject?.name ?: "دستخط من",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "زبان: ${if (currentProject?.language == "ENGLISH") "English" else "فارسی"} | نسخه ${currentProject?.version ?: "1.0"}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = if (ttfFile != null) "TTF آماده" else "در حال تکمیل",
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        // Completion Progress
                        val completion = stats?.completionPercentage ?: 0
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("پیشرفت ثبت حروف", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("$completion%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { completion / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f)
                        )

                        Spacer(Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onNavigate(ScreenRoute.GlyphCollection.route) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("hero_continue_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Create, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("ادامه نوشتن حروف", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { viewModel.generateTtf() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("hero_build_ttf_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("تولید فایل TTF", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Grid Cards
            items(actionItems.size) { index ->
                val item = actionItems[index]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(135.dp)
                        .clickable { onNavigate(item.route) }
                        .testTag(item.testTag),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(item.color.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(item.icon, contentDescription = item.title, tint = item.color, modifier = Modifier.size(24.dp))
                        }

                        Column {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                item.subtitle,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
