package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.GlyphForm
import com.example.ui.components.DrawingToolBar
import com.example.ui.components.StylusCanvas
import com.example.ui.viewmodel.FontStudioViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlyphCollectionScreen(
    viewModel: FontStudioViewModel,
    onBack: () -> Unit
) {
    val currentReq = viewModel.currentRequirement()
    val currentIndex by viewModel.currentWizardIndex.collectAsState()
    val allReqs by viewModel.wizardRequirements.collectAsState()
    val strokes by viewModel.currentStrokes.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()
    val savedGlyphs by viewModel.projectGlyphs.collectAsState()

    val currentTool by viewModel.currentTool.collectAsState()
    val currentColor by viewModel.currentColorArgb.collectAsState()
    val currentStrokeWidth by viewModel.currentStrokeWidth.collectAsState()
    val pencilHardness by viewModel.pencilHardness.collectAsState()
    val penType by viewModel.penType.collectAsState()

    var showOverviewSheet by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = currentReq?.name ?: "جمع‌آوری حروف",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = "حرف ${currentIndex + 1} از ${allReqs.size}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("collection_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showOverviewSheet = true },
                        modifier = Modifier.testTag("glyph_list_overview_button")
                    ) {
                        Icon(Icons.Default.FormatListNumbered, contentDescription = "All Glyphs")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("glyph_collection_screen")
        ) {
            // 1. Progress Bar across entire alphabet
            val progress = if (allReqs.isNotEmpty()) (currentIndex + 1).toFloat() / allReqs.size else 0f
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            // 2. Step-by-Step Prompt Instruction Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("glyph_instruction_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentReq?.guidePrompt ?: "حرف را با قلم داخل کادر بنویسید.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "حالت: ${currentReq?.form?.farsiLabel ?: "استاندارد"} | ${currentReq?.baselineHint ?: ""}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Sample glyph visual reference badge
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentReq?.sampleDisplay ?: "",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // 3. Navigation Controls Row (< قبلی | بعدی >)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.previousWizardGlyph() },
                    enabled = currentIndex > 0,
                    modifier = Modifier.testTag("prev_glyph_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Glyph")
                }

                Text(
                    text = "برای حروف بعدی می‌توانید مستقیماً دکمه «تأیید» را بزنید",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                IconButton(
                    onClick = { viewModel.nextWizardGlyph() },
                    enabled = currentIndex < allReqs.size - 1,
                    modifier = Modifier.testTag("next_glyph_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Glyph")
                }
            }

            // 4. White Canvas with Stylus & Finger Support
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                StylusCanvas(
                    modifier = Modifier.fillMaxSize(),
                    strokes = strokes,
                    currentTool = currentTool,
                    currentColor = currentColor,
                    currentStrokeWidth = currentStrokeWidth,
                    pencilHardness = pencilHardness,
                    showGuides = true,
                    isAscender = currentReq?.isAscender ?: false,
                    isDescender = currentReq?.isDescender ?: false,
                    onStrokeFinished = { stroke ->
                        viewModel.addStroke(stroke)
                    }
                )
            }

            // 5. Drawing Toolbar (Pen/Pencil/Eraser/Colors/Undo/Redo/Confirm)
            DrawingToolBar(
                currentTool = currentTool,
                currentColorArgb = currentColor,
                currentStrokeWidth = currentStrokeWidth,
                pencilHardness = pencilHardness,
                penType = penType,
                canUndo = canUndo,
                canRedo = canRedo,
                onToolSelected = { viewModel.currentTool.value = it },
                onColorSelected = { viewModel.currentColorArgb.value = it },
                onStrokeWidthChanged = { viewModel.currentStrokeWidth.value = it },
                onPencilHardnessSelected = { viewModel.pencilHardness.value = it },
                onPenTypeSelected = { viewModel.penType.value = it },
                onUndo = { viewModel.undo() },
                onRedo = { viewModel.redo() },
                onClear = { viewModel.clearCanvas() },
                onConfirm = { viewModel.confirmCurrentGlyph() }
            )
        }
    }

    // Modal sheet to jump to any glyph
    if (showOverviewSheet) {
        val sheetState = rememberModalBottomSheetState()
        ModalBottomSheet(
            onDismissRequest = { showOverviewSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("glyph_overview_sheet")
            ) {
                Text(
                    text = "فهرست تمام حروف و نشانه‌ها",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(Modifier.height(10.dp))

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(allReqs) { idx, req ->
                        val isDone = savedGlyphs.any { it.glyphName == req.name && it.strokesJson != "[]" }
                        val isCurrent = idx == currentIndex
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    when {
                                        isCurrent -> MaterialTheme.colorScheme.primary
                                        isDone -> MaterialTheme.colorScheme.primaryContainer
                                        else -> MaterialTheme.colorScheme.surfaceVariant
                                    }
                                )
                                .clickable {
                                    viewModel.setWizardIndex(idx)
                                    showOverviewSheet = false
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = req.sampleDisplay,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}
