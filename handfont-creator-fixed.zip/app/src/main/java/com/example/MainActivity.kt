package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.ScreenRoute
import com.example.ui.screens.FontInspectorScreen
import com.example.ui.screens.FontPreviewScreen
import com.example.ui.screens.FreeCanvasScreen
import com.example.ui.screens.GlyphCollectionScreen
import com.example.ui.screens.HandwritingTestScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyProjectsScreen
import com.example.ui.screens.PaperWriterScreen
import com.example.ui.screens.PdfMakerScreen
import com.example.ui.screens.PhotoExtractionScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SignatureMakerScreen
import com.example.ui.theme.HandFontTheme
import com.example.ui.viewmodel.FontStudioViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            HandFontTheme {
                val navController = rememberNavController()
                val studioViewModel: FontStudioViewModel = viewModel()
                val snackbarHostState = remember { SnackbarHostState() }
                val statusMessage by studioViewModel.statusMessage.collectAsState()

                LaunchedEffect(statusMessage) {
                    statusMessage?.let { msg ->
                        snackbarHostState.showSnackbar(msg)
                        studioViewModel.clearStatusMessage()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = ScreenRoute.Home.route,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        composable(ScreenRoute.Home.route) {
                            HomeScreen(
                                viewModel = studioViewModel,
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }

                        composable(ScreenRoute.GlyphCollection.route) {
                            GlyphCollectionScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.FontPreview.route) {
                            FontPreviewScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.PaperWriter.route) {
                            PaperWriterScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.PdfMaker.route) {
                            PdfMakerScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.SignatureMaker.route) {
                            SignatureMakerScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.HandwritingTest.route) {
                            HandwritingTestScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() },
                                onNavigateToCollection = {
                                    navController.navigate(ScreenRoute.GlyphCollection.route)
                                }
                            )
                        }

                        composable(ScreenRoute.FreeCanvas.route) {
                            FreeCanvasScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.PhotoExtraction.route) {
                            PhotoExtractionScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.FontInspector.route) {
                            FontInspectorScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.MyProjects.route) {
                            MyProjectsScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable(ScreenRoute.Settings.route) {
                            SettingsScreen(
                                viewModel = studioViewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
