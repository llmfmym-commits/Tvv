package com.example.engine.catalog

import com.example.data.models.GlyphForm
import com.example.data.models.Language

data class GlyphRequirement(
    val charCode: Int,
    val name: String,
    val form: GlyphForm,
    val guidePrompt: String,
    val sampleDisplay: String,
    val baselineHint: String = "روی خط زمینه بنویسید",
    val isAscender: Boolean = false,
    val isDescender: Boolean = false
)

object GlyphCatalog {

    fun getRequirementsForLanguage(language: Language): List<GlyphRequirement> {
        return when (language) {
            Language.PERSIAN -> getPersianRequirements()
            Language.ENGLISH -> getEnglishRequirements()
        }
    }

    private fun getPersianRequirements(): List<GlyphRequirement> {
        val list = mutableListOf<GlyphRequirement>()

        // Helper
        fun addDual(char: Char, name: String, unicodeIso: Int, unicodeFin: Int, isDesc: Boolean = false, isAsc: Boolean = false) {
            list.add(GlyphRequirement(unicodeIso, "${name}_تنها", GlyphForm.ISOLATED, "لطفاً «$char» به‌صورت تنها را بنویسید.", "$char", isDescender = isDesc, isAscender = isAsc))
            list.add(GlyphRequirement(unicodeFin, "${name}_آخر", GlyphForm.FINAL, "لطفاً «$char» در حالت متصل به قبل (آخر) را بنویسید.", "ـ$char", isDescender = isDesc, isAscender = isAsc))
        }

        fun addQuad(char: Char, name: String, uIso: Int, uIni: Int, uMed: Int, uFin: Int, isDesc: Boolean = false, isAsc: Boolean = false) {
            list.add(GlyphRequirement(uIso, "${name}_تنها", GlyphForm.ISOLATED, "لطفاً «$char» به‌صورت تنها را بنویسید.", "$char", isDescender = isDesc, isAscender = isAsc))
            list.add(GlyphRequirement(uIni, "${name}_اول", GlyphForm.INITIAL, "لطفاً «$char» در حالت متصل به بعد (اول کلمه) را بنویسید.", "${char}ـ", isDescender = isDesc, isAscender = isAsc))
            list.add(GlyphRequirement(uMed, "${name}_وسط", GlyphForm.MEDIAL, "لطفاً «$char» در حالت متصل از هر دو طرف (وسط کلمه) را بنویسید.", "ـ${char}ـ", isDescender = isDesc, isAscender = isAsc))
            list.add(GlyphRequirement(uFin, "${name}_آخر", GlyphForm.FINAL, "لطفاً «$char» در حالت متصل از راست (آخر کلمه) را بنویسید.", "ـ$char", isDescender = isDesc, isAscender = isAsc))
        }

        // الف و آ
        list.add(GlyphRequirement('آ'.code, "الف_کلاه_دار", GlyphForm.ISOLATED, "لطفاً «آ» به‌صورت تنها را بنویسید.", "آ", isAscender = true))
        addDual('ا', "الف", 'ا'.code, 0xFE8E, isAsc = true)

        // ب پ ت ث
        addQuad('ب', "ب", 'ب'.code, 0xFE91, 0xFE92, 0xFE90)
        addQuad('پ', "پ", 'پ'.code, 0xFB58, 0xFB59, 0xFB57)
        addQuad('ت', "ت", 'ت'.code, 0xFE97, 0xFE98, 0xFE96)
        addQuad('ث', "ث", 'ث'.code, 0xFE9B, 0xFE9C, 0xFE9A)

        // ج چ ح خ
        addQuad('ج', "ج", 'ج'.code, 0xFE9F, 0xFEA0, 0xFE9E, isDesc = true)
        addQuad('چ', "چ", 'چ'.code, 0xFB7C, 0xFB7D, 0xFB7B, isDesc = true)
        addQuad('ح', "ح", 'ح'.code, 0xFEA3, 0xFEA4, 0xFEA2, isDesc = true)
        addQuad('خ', "خ", 'خ'.code, 0xFEA7, 0xFEA8, 0xFEA6, isDesc = true)

        // د ذ ر ز ژ
        addDual('د', "د", 'د'.code, 0xFEAA)
        addDual('ذ', "ذ", 'ذ'.code, 0xFEAC)
        addDual('ر', "ر", 'ر'.code, 0xFEAE, isDesc = true)
        addDual('ز', "ز", 'ز'.code, 0xFEB0, isDesc = true)
        addDual('ژ', "ژ", 'ژ'.code, 0xFB8B, isDesc = true)

        // س ش
        addQuad('س', "س", 'س'.code, 0xFEB3, 0xFEB4, 0xFEB2, isDesc = true)
        addQuad('ش', "ش", 'ش'.code, 0xFEB7, 0xFEB8, 0xFEB6, isDesc = true)

        // ص ض
        addQuad('ص', "ص", 'ص'.code, 0xFEBB, 0xFEBC, 0xFEBA, isDesc = true)
        addQuad('ض', "ض", 'ض'.code, 0xFEBF, 0xFEC0, 0xFEBE, isDesc = true)

        // ط ظ
        addQuad('ط', "ط", 'ط'.code, 0xFEC3, 0xFEC4, 0xFEC2, isAsc = true)
        addQuad('ظ', "ظ", 'ظ'.code, 0xFEC7, 0xFEC8, 0xFEC6, isAsc = true)

        // ع غ
        addQuad('ع', "ع", 'ع'.code, 0xFECB, 0xFECC, 0xFECA, isDesc = true)
        addQuad('غ', "غ", 'غ'.code, 0xFECF, 0xFED0, 0xFECE, isDesc = true)

        // ف ق
        addQuad('ف', "ف", 'ف'.code, 0xFED3, 0xFED4, 0xFED2)
        addQuad('ق', "ق", 'ق'.code, 0xFED7, 0xFED8, 0xFED6, isDesc = true)

        // ک گ
        addQuad('ک', "ک", 'ک'.code, 0xFB90, 0xFB91, 0xFB8F, isAsc = true)
        addQuad('گ', "گ", 'گ'.code, 0xFB94, 0xFB95, 0xFB93, isAsc = true)

        // ل
        addQuad('ل', "ل", 'ل'.code, 0xFEDF, 0xFEE0, 0xFEDE, isAsc = true)

        // م
        addQuad('م', "م", 'م'.code, 0xFEE3, 0xFEE4, 0xFEE2, isDesc = true)

        // ن
        addQuad('ن', "ن", 'ن'.code, 0xFEE7, 0xFEE8, 0xFEE6, isDesc = true)

        // و
        addDual('و', "و", 'و'.code, 0xFEEE)

        // ه
        addQuad('ه', "ه", 'ه'.code, 0xFEEB, 0xFEEC, 0xFEEA)

        // ی
        addQuad('ی', "ی", 'ی'.code, 0xFBFE, 0xFBFF, 0xFBFD, isDesc = true)

        // اعداد فارسی
        val digits = listOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
        for (d in digits) {
            list.add(GlyphRequirement(d.code, "عدد_$d", GlyphForm.NONE, "لطفاً عدد «$d» را بنویسید.", "$d"))
        }

        // علائم نگارشی فارسی
        val puncts = listOf('،', '؛', '؟', '!', '.', '«', '»', '-')
        for (p in puncts) {
            list.add(GlyphRequirement(p.code, "علامت_$p", GlyphForm.NONE, "لطفاً نشانه «$p» را بنویسید.", "$p"))
        }

        return list
    }

    private fun getEnglishRequirements(): List<GlyphRequirement> {
        val list = mutableListOf<GlyphRequirement>()

        // Uppercase A-Z
        for (c in 'A'..'Z') {
            list.add(GlyphRequirement(c.code, "Letter_$c", GlyphForm.NONE, "Please write uppercase '$c'", "$c", isAscender = true))
        }

        // Lowercase a-z
        val descenders = setOf('g', 'j', 'p', 'q', 'y')
        val ascenders = setOf('b', 'd', 'f', 'h', 'k', 'l', 't')
        for (c in 'a'..'z') {
            list.add(
                GlyphRequirement(
                    c.code,
                    "letter_$c",
                    GlyphForm.NONE,
                    "Please write lowercase '$c'",
                    "$c",
                    isAscender = ascenders.contains(c),
                    isDescender = descenders.contains(c)
                )
            )
        }

        // Digits 0-9
        for (d in '0'..'9') {
            list.add(GlyphRequirement(d.code, "Digit_$d", GlyphForm.NONE, "Please write digit '$d'", "$d"))
        }

        // Punctuation
        val punct = listOf('.', ',', '!', '?', ';', ':', '-', '(', ')', '"', '\'', '@', '&', '+', '=', '/', '#')
        for (p in punct) {
            list.add(GlyphRequirement(p.code, "Symbol_$p", GlyphForm.NONE, "Please write symbol '$p'", "$p"))
        }

        return list
    }
}
