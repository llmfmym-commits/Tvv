package com.example.data.models

enum class Language(val displayName: String, val nativeName: String) {
    PERSIAN("Persian", "فارسی"),
    ENGLISH("English", "English")
}

enum class GlyphForm(val label: String, val farsiLabel: String) {
    ISOLATED("Isolated", "تنها"),
    INITIAL("Initial", "اول"),
    MEDIAL("Medial", "وسط"),
    FINAL("Final", "آخر"),
    NONE("Standard", "استاندارد")
}

enum class ToolType(val title: String) {
    PENCIL("مداد"),
    PEN("خودکار"),
    ERASER("پاک‌کن")
}

enum class PencilHardness(val code: String, val darknessFactor: Float, val softness: Float) {
    HB("HB", 0.75f, 1.0f),
    B2("2B", 0.85f, 1.2f),
    B4("4B", 0.95f, 1.4f),
    B6("6B", 1.0f, 1.7f)
}

enum class PenType(val title: String, val inkFlow: Float) {
    BALLPOINT("خودکار معمولی", 0.85f),
    FINELINER("نوک‌ریز", 0.70f),
    GEL("ژله‌ای", 1.0f),
    MARKER("ماژیک", 1.3f)
}

enum class StylePreset(val title: String, val farsiTitle: String, val naturalness: Float, val slant: Float) {
    FORMAL("Formal", "رسمی", 0.15f, 0.0f),
    NEAT("Neat", "مرتب", 0.30f, 0.0f),
    CASUAL("Casual", "معمولی", 0.55f, 1.5f),
    QUICK("Quick", "سریع", 0.70f, 3.0f),
    NATURAL("Natural", "طبیعی", 0.85f, 1.0f),
    SIGNATURE("Signature", "امضایی", 0.95f, -2.0f)
}

data class StrokePoint(
    val x: Float,
    val y: Float,
    val pressure: Float = 0.5f,
    val timestamp: Long = System.currentTimeMillis()
)

data class DrawnStroke(
    val points: List<StrokePoint> = emptyList(),
    val tool: ToolType = ToolType.PENCIL,
    val colorArgb: Long = 0xFF2A2A2AL,
    val strokeWidth: Float = 12f,
    val pencilHardness: PencilHardness = PencilHardness.B2,
    val penType: PenType = PenType.BALLPOINT
)

data class GlyphOutlineContour(
    val points: List<ContourPoint> = emptyList()
)

data class ContourPoint(
    val x: Int,
    val y: Int,
    val onCurve: Boolean = true
)

data class GlyphMetric(
    val advanceWidth: Int,
    val leftSideBearing: Int,
    val rightSideBearing: Int,
    val xMin: Int,
    val yMin: Int,
    val xMax: Int,
    val yMax: Int
)

data class KerningAdjustment(
    val firstChar: Char,
    val secondChar: Char,
    val amount: Int
)

data class HandwritingStats(
    val totalRequiredGlyphs: Int,
    val capturedGlyphs: Int,
    val completionPercentage: Int,
    val missingGlyphNames: List<String>,
    val needsReviewCount: Int
)
